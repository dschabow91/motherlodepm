# CMMS Frontend
Use React to create login, dashboard, PM, report, and inventory views.
