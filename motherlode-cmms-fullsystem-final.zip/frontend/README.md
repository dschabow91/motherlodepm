# CMMS React Frontend
Build UI here: login, dashboard, tasks, inventory, etc.